﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtMake = New System.Windows.Forms.Label()
        Me.txtColor = New System.Windows.Forms.Label()
        Me.txtCal = New System.Windows.Forms.Label()
        Me.txtModel = New System.Windows.Forms.Label()
        Me.txtSerial = New System.Windows.Forms.Label()
        Me.txtDueBack = New System.Windows.Forms.Label()
        Me.makeBox = New System.Windows.Forms.ListBox()
        Me.modelBox = New System.Windows.Forms.ListBox()
        Me.serialBox = New System.Windows.Forms.TextBox()
        Me.calBox = New System.Windows.Forms.TextBox()
        Me.colorBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(3, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1348, 652)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Gray
        Me.TabPage1.BackgroundImage = CType(resources.GetObject("TabPage1.BackgroundImage"), System.Drawing.Image)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.colorBox)
        Me.TabPage1.Controls.Add(Me.calBox)
        Me.TabPage1.Controls.Add(Me.serialBox)
        Me.TabPage1.Controls.Add(Me.modelBox)
        Me.TabPage1.Controls.Add(Me.makeBox)
        Me.TabPage1.Controls.Add(Me.txtDueBack)
        Me.TabPage1.Controls.Add(Me.txtCal)
        Me.TabPage1.Controls.Add(Me.txtModel)
        Me.TabPage1.Controls.Add(Me.txtSerial)
        Me.TabPage1.Controls.Add(Me.txtColor)
        Me.TabPage1.Controls.Add(Me.txtMake)
        Me.TabPage1.Controls.Add(Me.DateTimePicker1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 34)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1340, 614)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Details"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.DarkGray
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 34)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1340, 614)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Settings"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Silver
        Me.TabPage3.Location = New System.Drawing.Point(4, 34)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1340, 614)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "TabPage3"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.txtUsername)
        Me.GroupBox1.Controls.Add(Me.btnExit)
        Me.GroupBox1.Controls.Add(Me.btnReset)
        Me.GroupBox1.Controls.Add(Me.btnLogin)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(1334, 596)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1348, 652)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(659, 342)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(136, 31)
        Me.txtPassword.TabIndex = 8
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(659, 298)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(136, 31)
        Me.txtUsername.TabIndex = 7
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(798, 396)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(651, 396)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 5
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnLogin
        '
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.Location = New System.Drawing.Point(509, 396)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(75, 23)
        Me.btnLogin.TabIndex = 4
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(528, 342)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Password:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(528, 304)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Username:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(491, 154)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(403, 123)
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Location = New System.Drawing.Point(-4, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1344, 611)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "GroupBox2"
        '
        'txtMake
        '
        Me.txtMake.AutoSize = True
        Me.txtMake.BackColor = System.Drawing.Color.Transparent
        Me.txtMake.ForeColor = System.Drawing.SystemColors.Control
        Me.txtMake.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtMake.Location = New System.Drawing.Point(827, 117)
        Me.txtMake.Name = "txtMake"
        Me.txtMake.Size = New System.Drawing.Size(69, 25)
        Me.txtMake.TabIndex = 1
        Me.txtMake.Text = "Make"
        Me.txtMake.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtColor
        '
        Me.txtColor.AutoSize = True
        Me.txtColor.BackColor = System.Drawing.Color.Transparent
        Me.txtColor.ForeColor = System.Drawing.SystemColors.Control
        Me.txtColor.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtColor.Location = New System.Drawing.Point(828, 412)
        Me.txtColor.Name = "txtColor"
        Me.txtColor.Size = New System.Drawing.Size(68, 25)
        Me.txtColor.TabIndex = 2
        Me.txtColor.Text = "Color"
        Me.txtColor.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtCal
        '
        Me.txtCal.AutoSize = True
        Me.txtCal.BackColor = System.Drawing.Color.Transparent
        Me.txtCal.ForeColor = System.Drawing.SystemColors.Control
        Me.txtCal.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtCal.Location = New System.Drawing.Point(809, 340)
        Me.txtCal.Name = "txtCal"
        Me.txtCal.Size = New System.Drawing.Size(87, 25)
        Me.txtCal.TabIndex = 3
        Me.txtCal.Text = "Caliber"
        Me.txtCal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtModel
        '
        Me.txtModel.AutoSize = True
        Me.txtModel.BackColor = System.Drawing.Color.Transparent
        Me.txtModel.ForeColor = System.Drawing.SystemColors.Control
        Me.txtModel.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtModel.Location = New System.Drawing.Point(820, 187)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(76, 25)
        Me.txtModel.TabIndex = 2
        Me.txtModel.Text = "Model"
        Me.txtModel.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtSerial
        '
        Me.txtSerial.AutoSize = True
        Me.txtSerial.BackColor = System.Drawing.Color.Transparent
        Me.txtSerial.ForeColor = System.Drawing.SystemColors.Control
        Me.txtSerial.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtSerial.Location = New System.Drawing.Point(735, 260)
        Me.txtSerial.Name = "txtSerial"
        Me.txtSerial.Size = New System.Drawing.Size(161, 25)
        Me.txtSerial.TabIndex = 2
        Me.txtSerial.Text = "Serial Number"
        Me.txtSerial.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtDueBack
        '
        Me.txtDueBack.AutoSize = True
        Me.txtDueBack.BackColor = System.Drawing.Color.Transparent
        Me.txtDueBack.ForeColor = System.Drawing.SystemColors.Control
        Me.txtDueBack.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtDueBack.Location = New System.Drawing.Point(783, 481)
        Me.txtDueBack.Name = "txtDueBack"
        Me.txtDueBack.Size = New System.Drawing.Size(113, 25)
        Me.txtDueBack.TabIndex = 4
        Me.txtDueBack.Text = "Due Back"
        Me.txtDueBack.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'makeBox
        '
        Me.makeBox.FormattingEnabled = True
        Me.makeBox.ItemHeight = 25
        Me.makeBox.Items.AddRange(New Object() {"Assault Rifle - Auto", "Assault Rifle - Semi-Auto", "Rifle", "Pistol"})
        Me.makeBox.Location = New System.Drawing.Point(916, 117)
        Me.makeBox.Name = "makeBox"
        Me.makeBox.Size = New System.Drawing.Size(262, 29)
        Me.makeBox.TabIndex = 5
        '
        'modelBox
        '
        Me.modelBox.FormattingEnabled = True
        Me.modelBox.ItemHeight = 25
        Me.modelBox.Items.AddRange(New Object() {"BLAH", "BLAH", "BLAH"})
        Me.modelBox.Location = New System.Drawing.Point(916, 187)
        Me.modelBox.Name = "modelBox"
        Me.modelBox.Size = New System.Drawing.Size(262, 29)
        Me.modelBox.TabIndex = 6
        '
        'serialBox
        '
        Me.serialBox.Location = New System.Drawing.Point(916, 254)
        Me.serialBox.Name = "serialBox"
        Me.serialBox.Size = New System.Drawing.Size(262, 31)
        Me.serialBox.TabIndex = 7
        '
        'calBox
        '
        Me.calBox.Location = New System.Drawing.Point(916, 334)
        Me.calBox.Name = "calBox"
        Me.calBox.Size = New System.Drawing.Size(262, 31)
        Me.calBox.TabIndex = 8
        '
        'colorBox
        '
        Me.colorBox.Location = New System.Drawing.Point(916, 406)
        Me.colorBox.Name = "colorBox"
        Me.colorBox.Size = New System.Drawing.Size(262, 31)
        Me.colorBox.TabIndex = 9
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Location = New System.Drawing.Point(916, 543)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(262, 42)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Check Out"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.SystemColors.Control
        Me.Label9.Location = New System.Drawing.Point(987, 39)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(122, 25)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Check Out"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.SystemColors.Control
        Me.Label10.Location = New System.Drawing.Point(220, 39)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(251, 25)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Currently Checked Out"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(144, 117)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(406, 468)
        Me.DataGridView1.TabIndex = 14
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Checked = False
        Me.DateTimePicker1.CustomFormat = ""
        Me.DateTimePicker1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.DateTimePicker1.Location = New System.Drawing.Point(916, 475)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(262, 26)
        Me.DateTimePicker1.TabIndex = 16
        Me.DateTimePicker1.Value = New Date(2018, 3, 18, 15, 5, 52, 0)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1352, 661)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnLogin As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents colorBox As TextBox
    Friend WithEvents calBox As TextBox
    Friend WithEvents serialBox As TextBox
    Friend WithEvents modelBox As ListBox
    Friend WithEvents makeBox As ListBox
    Friend WithEvents txtDueBack As Label
    Friend WithEvents txtCal As Label
    Friend WithEvents txtModel As Label
    Friend WithEvents txtSerial As Label
    Friend WithEvents txtColor As Label
    Friend WithEvents txtMake As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
End Class
