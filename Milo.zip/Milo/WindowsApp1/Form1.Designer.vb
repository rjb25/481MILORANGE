﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.colorBox = New System.Windows.Forms.TextBox()
        Me.calBox = New System.Windows.Forms.TextBox()
        Me.serialBox = New System.Windows.Forms.TextBox()
        Me.modelBox = New System.Windows.Forms.ListBox()
        Me.makeBox = New System.Windows.Forms.ListBox()
        Me.txtDueBack = New System.Windows.Forms.Label()
        Me.txtCal = New System.Windows.Forms.Label()
        Me.txtModel = New System.Windows.Forms.Label()
        Me.txtSerial = New System.Windows.Forms.Label()
        Me.txtColor = New System.Windows.Forms.Label()
        Me.txtMake = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.btnAdminSettings = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(4, 15)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1797, 802)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Gray
        Me.TabPage1.BackgroundImage = CType(resources.GetObject("TabPage1.BackgroundImage"), System.Drawing.Image)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.colorBox)
        Me.TabPage1.Controls.Add(Me.calBox)
        Me.TabPage1.Controls.Add(Me.serialBox)
        Me.TabPage1.Controls.Add(Me.modelBox)
        Me.TabPage1.Controls.Add(Me.makeBox)
        Me.TabPage1.Controls.Add(Me.txtDueBack)
        Me.TabPage1.Controls.Add(Me.txtCal)
        Me.TabPage1.Controls.Add(Me.txtModel)
        Me.TabPage1.Controls.Add(Me.txtSerial)
        Me.TabPage1.Controls.Add(Me.txtColor)
        Me.TabPage1.Controls.Add(Me.txtMake)
        Me.TabPage1.Controls.Add(Me.DateTimePicker1)
        Me.TabPage1.Controls.Add(Me.btnAdminSettings)
        Me.TabPage1.Location = New System.Drawing.Point(4, 39)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage1.Size = New System.Drawing.Size(1789, 759)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Details"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.txtPassword)
        Me.GroupBox1.Controls.Add(Me.txtUsername)
        Me.GroupBox1.Controls.Add(Me.btnExit)
        Me.GroupBox1.Controls.Add(Me.btnReset)
        Me.GroupBox1.Controls.Add(Me.btnLogin)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(1779, 734)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(1797, 802)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(655, 190)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(537, 151)
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(879, 421)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(180, 37)
        Me.txtPassword.TabIndex = 8
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(879, 367)
        Me.txtUsername.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(180, 37)
        Me.txtUsername.TabIndex = 7
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(1064, 487)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(100, 28)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(868, 487)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(100, 28)
        Me.btnReset.TabIndex = 5
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnLogin
        '
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.Location = New System.Drawing.Point(679, 487)
        Me.btnLogin.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(100, 28)
        Me.btnLogin.TabIndex = 4
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(704, 421)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(151, 31)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Password:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(704, 374)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(156, 31)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Username:"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(192, 144)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(541, 576)
        Me.DataGridView1.TabIndex = 14
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.SystemColors.Control
        Me.Label10.Location = New System.Drawing.Point(293, 48)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(312, 31)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Currently Checked Out"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.SystemColors.Control
        Me.Label9.Location = New System.Drawing.Point(1316, 48)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(152, 31)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Check Out"
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Location = New System.Drawing.Point(1221, 668)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(349, 52)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Check Out"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'colorBox
        '
        Me.colorBox.Location = New System.Drawing.Point(1221, 500)
        Me.colorBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.colorBox.Name = "colorBox"
        Me.colorBox.Size = New System.Drawing.Size(348, 37)
        Me.colorBox.TabIndex = 9
        '
        'calBox
        '
        Me.calBox.Location = New System.Drawing.Point(1221, 411)
        Me.calBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.calBox.Name = "calBox"
        Me.calBox.Size = New System.Drawing.Size(348, 37)
        Me.calBox.TabIndex = 8
        '
        'serialBox
        '
        Me.serialBox.Location = New System.Drawing.Point(1221, 313)
        Me.serialBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.serialBox.Name = "serialBox"
        Me.serialBox.Size = New System.Drawing.Size(348, 37)
        Me.serialBox.TabIndex = 7
        '
        'modelBox
        '
        Me.modelBox.FormattingEnabled = True
        Me.modelBox.ItemHeight = 30
        Me.modelBox.Items.AddRange(New Object() {"BLAH", "BLAH", "BLAH"})
        Me.modelBox.Location = New System.Drawing.Point(1221, 230)
        Me.modelBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.modelBox.Name = "modelBox"
        Me.modelBox.Size = New System.Drawing.Size(348, 34)
        Me.modelBox.TabIndex = 6
        '
        'makeBox
        '
        Me.makeBox.FormattingEnabled = True
        Me.makeBox.ItemHeight = 30
        Me.makeBox.Items.AddRange(New Object() {"Assault Rifle - Auto", "Assault Rifle - Semi-Auto", "Rifle", "Pistol"})
        Me.makeBox.Location = New System.Drawing.Point(1221, 144)
        Me.makeBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.makeBox.Name = "makeBox"
        Me.makeBox.Size = New System.Drawing.Size(348, 34)
        Me.makeBox.TabIndex = 5
        '
        'txtDueBack
        '
        Me.txtDueBack.AutoSize = True
        Me.txtDueBack.BackColor = System.Drawing.Color.Transparent
        Me.txtDueBack.ForeColor = System.Drawing.SystemColors.Control
        Me.txtDueBack.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtDueBack.Location = New System.Drawing.Point(1044, 592)
        Me.txtDueBack.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtDueBack.Name = "txtDueBack"
        Me.txtDueBack.Size = New System.Drawing.Size(140, 31)
        Me.txtDueBack.TabIndex = 4
        Me.txtDueBack.Text = "Due Back"
        Me.txtDueBack.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtCal
        '
        Me.txtCal.AutoSize = True
        Me.txtCal.BackColor = System.Drawing.Color.Transparent
        Me.txtCal.ForeColor = System.Drawing.SystemColors.Control
        Me.txtCal.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtCal.Location = New System.Drawing.Point(1079, 418)
        Me.txtCal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtCal.Name = "txtCal"
        Me.txtCal.Size = New System.Drawing.Size(107, 31)
        Me.txtCal.TabIndex = 3
        Me.txtCal.Text = "Caliber"
        Me.txtCal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtModel
        '
        Me.txtModel.AutoSize = True
        Me.txtModel.BackColor = System.Drawing.Color.Transparent
        Me.txtModel.ForeColor = System.Drawing.SystemColors.Control
        Me.txtModel.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtModel.Location = New System.Drawing.Point(1093, 230)
        Me.txtModel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(92, 31)
        Me.txtModel.TabIndex = 2
        Me.txtModel.Text = "Model"
        Me.txtModel.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtSerial
        '
        Me.txtSerial.AutoSize = True
        Me.txtSerial.BackColor = System.Drawing.Color.Transparent
        Me.txtSerial.ForeColor = System.Drawing.SystemColors.Control
        Me.txtSerial.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtSerial.Location = New System.Drawing.Point(980, 320)
        Me.txtSerial.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtSerial.Name = "txtSerial"
        Me.txtSerial.Size = New System.Drawing.Size(199, 31)
        Me.txtSerial.TabIndex = 2
        Me.txtSerial.Text = "Serial Number"
        Me.txtSerial.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtColor
        '
        Me.txtColor.AutoSize = True
        Me.txtColor.BackColor = System.Drawing.Color.Transparent
        Me.txtColor.ForeColor = System.Drawing.SystemColors.Control
        Me.txtColor.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtColor.Location = New System.Drawing.Point(1104, 507)
        Me.txtColor.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtColor.Name = "txtColor"
        Me.txtColor.Size = New System.Drawing.Size(84, 31)
        Me.txtColor.TabIndex = 2
        Me.txtColor.Text = "Color"
        Me.txtColor.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMake
        '
        Me.txtMake.AutoSize = True
        Me.txtMake.BackColor = System.Drawing.Color.Transparent
        Me.txtMake.ForeColor = System.Drawing.SystemColors.Control
        Me.txtMake.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.txtMake.Location = New System.Drawing.Point(1103, 144)
        Me.txtMake.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtMake.Name = "txtMake"
        Me.txtMake.Size = New System.Drawing.Size(84, 31)
        Me.txtMake.TabIndex = 1
        Me.txtMake.Text = "Make"
        Me.txtMake.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Checked = False
        Me.DateTimePicker1.CustomFormat = ""
        Me.DateTimePicker1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.DateTimePicker1.Location = New System.Drawing.Point(1221, 585)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(348, 30)
        Me.DateTimePicker1.TabIndex = 16
        Me.DateTimePicker1.Value = New Date(2018, 3, 18, 15, 5, 52, 0)
        '
        'btnAdminSettings
        '
        Me.btnAdminSettings.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdminSettings.Location = New System.Drawing.Point(13, 12)
        Me.btnAdminSettings.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAdminSettings.Name = "btnAdminSettings"
        Me.btnAdminSettings.Size = New System.Drawing.Size(181, 38)
        Me.btnAdminSettings.TabIndex = 6
        Me.btnAdminSettings.Text = "Administrator Settings"
        Me.btnAdminSettings.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.DarkGray
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 39)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage2.Size = New System.Drawing.Size(1789, 759)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Settings"
        '
        'GroupBox2
        '
        Me.GroupBox2.Location = New System.Drawing.Point(-5, 4)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(1792, 752)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "GroupBox2"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Silver
        Me.TabPage3.BackgroundImage = CType(resources.GetObject("TabPage3.BackgroundImage"), System.Drawing.Image)
        Me.TabPage3.Controls.Add(Me.Button4)
        Me.TabPage3.Controls.Add(Me.Button3)
        Me.TabPage3.Controls.Add(Me.Button2)
        Me.TabPage3.Controls.Add(Me.Label1)
        Me.TabPage3.Controls.Add(Me.DataGridView2)
        Me.TabPage3.Location = New System.Drawing.Point(4, 39)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage3.Size = New System.Drawing.Size(1789, 759)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Admin Settings"
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(198, 175)
        Me.DataGridView2.Margin = New System.Windows.Forms.Padding(4)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(541, 576)
        Me.DataGridView2.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(364, 76)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(197, 31)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Current Users"
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button2.Location = New System.Drawing.Point(801, 175)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(360, 43)
        Me.Button2.TabIndex = 17
        Me.Button2.Text = "Change Username"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button3.Location = New System.Drawing.Point(801, 260)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(360, 43)
        Me.Button3.TabIndex = 18
        Me.Button3.Text = "Change Password"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button4.Location = New System.Drawing.Point(801, 350)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(360, 43)
        Me.Button4.TabIndex = 19
        Me.Button4.Text = "Delete User"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1803, 814)
        Me.Controls.Add(Me.TabControl1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnAdminSettings As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnLogin As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents colorBox As TextBox
    Friend WithEvents calBox As TextBox
    Friend WithEvents serialBox As TextBox
    Friend WithEvents modelBox As ListBox
    Friend WithEvents makeBox As ListBox
    Friend WithEvents txtDueBack As Label
    Friend WithEvents txtCal As Label
    Friend WithEvents txtModel As Label
    Friend WithEvents txtSerial As Label
    Friend WithEvents txtColor As Label
    Friend WithEvents txtMake As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
End Class
